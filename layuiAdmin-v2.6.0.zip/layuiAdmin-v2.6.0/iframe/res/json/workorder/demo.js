{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "orderid": 111
    ,"title": "张三是谁？"
    ,"attr": "公告"
    ,"progress": "25%"
    ,"submit": "tester"
    ,"accept": "员工-1"
    ,"state": "处理中"
  },{
    "orderid": 222
    ,"title": "Layui 怎么实现表单设计器？"
    ,"attr": "讨论"
    ,"progress": "100%"
    ,"submit": "张三"
    ,"accept": "员工-1"
    ,"state": "已处理"
  },{
    "orderid": 333
    ,"title": "张三是如何自学前端开发的"
    ,"attr": "分享"
    ,"progress": "0%"
    ,"submit": "张三"
    ,"accept": ""
    ,"state": "未分配"
  },{
    "orderid": 444
    ,"title": "PS 软件怎么安装与卸载？"
    ,"attr": "提问"
    ,"progress": "0%"
    ,"submit": "张三"
    ,"accept": ""
    ,"state": "未分配"
  },{
    "orderid": 555
    ,"title": "只会 PS 软件安装与卸载能找到工作吗？"
    ,"attr": "提问"
    ,"progress": "50%"
    ,"submit": "张三"
    ,"accept": "员工-2"
    ,"state": "处理中"
  },{
    "orderid": 55555
    ,"title": "无题"
    ,"attr": "公告"
    ,"progress": "25%"
    ,"submit": "张三"
    ,"accept": "员工-3"
    ,"state": "处理中"
  },{
    "orderid": 777
    ,"title": "前端岗位还有戏吗？"
    ,"attr": "提问"
    ,"progress": "100%"
    ,"submit": "张三"
    ,"accept": "员工-1"
    ,"state": "已处理"
  },{
    "orderid": 888
    ,"title": "提问提问提问"
    ,"attr": "提问"
    ,"progress": "0%"
    ,"submit": "张三"
    ,"accept": ""
    ,"state": "未分配"
  },{
    "orderid": 999
    ,"title": "提问提问提问"
    ,"attr": "提问"
    ,"progress": "50%"
    ,"submit": "张三"
    ,"accept": "员工-2"
    ,"state": "处理中"
  }]
}
