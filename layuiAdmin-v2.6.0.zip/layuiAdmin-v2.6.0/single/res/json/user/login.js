{
  "code": 0,
  "msg": "登录成功",
  "mark": "此处仅为静态模拟演示",
  "data": {
    "access_token": "TokenTestValue"
  }
}
